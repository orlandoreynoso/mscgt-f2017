<div class="titulo-iglesia">
	<h3>Selecciona tu iglesia</h3>
</div>
<article class="c-info" id="iglesia">
	<div id="div1" class="ig-p">
		<a href="<?php bloginfo('url'); ?>/category/tres-consejos/">
			<img src="<?php echo IMAGES.'/tresconsejos.png'; ?>" alt="">
			<span>Parroquia - Tres consejos</span>					
		</a>
	</div>
	<div id="div1" class="ig-p">
		<a href="<?php bloginfo('url'); ?>/molino-de-las-flores/">
			<img src="<?php echo IMAGES.'/santuario.png'; ?>" alt="">
			<span>Santuario NSSC</span>
		</a>
	</div>
	<div id="div1" class="ig-p">
		<a href="<?php bloginfo('url'); ?>/sede-parroquial-el-tesoro/">
			<img src="<?php echo IMAGES.'/tesoro.png'; ?>" alt="">
			<span>Sede Parroquial El Tesoro</span>
		</a>
	</div>
	<div id="div1" class="ig-p">
		<a href="<?php bloginfo('url'); ?>/rectoria-de-santa-rita/">
			<img src="<?php echo IMAGES.'/santarita.png'; ?>" alt="">
			<span>Rectoria de Santa Rita</span>
		</a>
	</div>
</article>