<div class="titulo-recomendaciones">
	<h3>Recomendaciones</h3>
</div>
<div class="c-recomendaciones">
<?php /*
	<?php get_laterales(1385,1,'Año de la misericordia','reflexiones'); ?>
	<?php get_laterales(1294,1,'Reflexiones Sacerdotales','reflexiones'); ?>			
	<?php get_laterales(1254,1,'Conozca Guatemala','reflexiones'); ?>
	<?php get_laterales(692,1,'Presentaciones','reflexiones'); ?>
	<?php get_laterales(737,1,'El atrio','reflexiones'); ?>
*/ 

get_recomendaciones_name('atrio');
/*
get_recomendaciones_home(1385,1,'Año de la misericordia');
get_recomendaciones_home(1294,1,'Reflexiones Sacerdotales');
get_recomendaciones_name('conozca-guatemala'); 
get_recomendaciones_home(692,1,'Presentaciones');
get_recomendaciones_name('atrio'); 
 */
?>	
</div>