<div>
	<?php  echo do_shortcode("[metaslider id=4323]");  ?>	
</div>